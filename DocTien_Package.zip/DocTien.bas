Attribute VB_Name = "DocTienModule"
Option Explicit

' Hàm chuyển đổi số thành chữ tiếng Việt
' Sử dụng: =DocTien(A1) hoặc =DocTien(12345)
Public Function DocTien(ByVal SoTien As Variant) As String
    On Error GoTo ErrorHandler
    
    ' Kiểm tra input
    If IsEmpty(SoTien) Or SoTien = "" Then
        DocTien = ""
        Exit Function
    End If
    
    ' Chuyển sang số
    Dim So As Double
    So = CDbl(SoTien)
    
    ' Kiểm tra số âm
    If So < 0 Then
        DocTien = "Âm " & DocSo(Abs(So))
    ElseIf So = 0 Then
        DocTien = "Không đồng"
    Else
        DocTien = DocSo(So)
    End If
    
    Exit Function
    
ErrorHandler:
    DocTien = "#LỖI: Giá trị không hợp lệ"
End Function

' Hàm phụ để đọc số
Private Function DocSo(ByVal So As Double) As String
    Dim strSo As String
    Dim strPhanNguyen As String
    Dim strPhanThapPhan As String
    Dim dblNguyen As Double
    Dim dblThapPhan As Double
    
    ' Tách phần nguyên và thập phân
    dblNguyen = Int(So)
    dblThapPhan = Round((So - dblNguyen) * 100, 0)
    
    ' Đọc phần nguyên
    strPhanNguyen = DocPhanNguyen(dblNguyen)
    
    ' Đọc phần thập phân (nếu có)
    If dblThapPhan > 0 Then
        strPhanThapPhan = " phẩy " & DocPhanNguyen(dblThapPhan)
        DocSo = strPhanNguyen & strPhanThapPhan & " đồng"
    Else
        DocSo = strPhanNguyen & " đồng"
    End If
End Function

' Đọc phần nguyên
Private Function DocPhanNguyen(ByVal So As Double) As String
    Dim Hangdonvi As String
    Dim strSo As String
    Dim i As Integer
    Dim Chuoi As String
    
    If So = 0 Then
        DocPhanNguyen = "Không"
        Exit Function
    End If
    
    strSo = CStr(So)
    Dim Hang As Long
    Hang = 1
    Chuoi = ""
    
    ' Đọc từng hàng
    Do While So > 0
        Dim SoCuoi As Integer
        SoCuoi = So Mod 1000
        
        If SoCuoi > 0 Then
            Dim strHang As String
            strHang = DocHangNguyen(SoCuoi, Hang)
            
            If Chuoi = "" Then
                Chuoi = strHang
            Else
                Chuoi = strHang & " " & DonViHang(Hang) & " " & Chuoi
            End If
        ElseIf Chuoi <> "" Then
            ' Có số ở hàng cao hơn
            Dim DonVi As String
            DonVi = DonViHang(Hang)
            If DonVi <> "" Then
                Chuoi = DonVi & " " & Chuoi
            End If
        End If
        
        So = Int(So / 1000)
        Hang = Hang + 1
    Loop
    
    ' Viết hoa chữ cái đầu
    If Len(Chuoi) > 0 Then
        Chuoi = UCase(Left(Chuoi, 1)) & Mid(Chuoi, 2)
    End If
    
    DocPhanNguyen = Chuoi
End Function

' Đọc 3 chữ số
Private Function DocHangNguyen(ByVal So As Integer, ByVal Hang As Long) As String
    Dim Tram As Integer, Chuc As Integer, Donvi As Integer
    Dim strKetQua As String
    
    Tram = Int(So / 100)
    Chuc = Int((So Mod 100) / 10)
    Donvi = So Mod 10
    
    strKetQua = ""
    
    ' Đọc hàng trăm
    If Tram > 0 Then
        strKetQua = DocChuSo(Tram) & " trăm"
    End If
    
    ' Đọc hàng chục
    If Chuc > 0 Then
        If strKetQua <> "" Then strKetQua = strKetQua & " "
        
        If Chuc = 1 Then
            strKetQua = strKetQua & "mười"
        Else
            strKetQua = strKetQua & DocChuSo(Chuc) & " mươi"
        End If
    ElseIf Donvi > 0 And Tram > 0 Then
        strKetQua = strKetQua & " lẻ"
    End If
    
    ' Đọc hàng đơn vị
    If Donvi > 0 Then
        If strKetQua <> "" Then strKetQua = strKetQua & " "
        
        If Donvi = 5 And Chuc >= 1 Then
            strKetQua = strKetQua & "lăm"
        ElseIf Donvi = 1 And Chuc >= 1 Then
            strKetQua = strKetQua & "mốt"
        Else
            strKetQua = strKetQua & DocChuSo(Donvi)
        End If
    End If
    
    DocHangNguyen = strKetQua
End Function

' Đọc chữ số đơn
Private Function DocChuSo(ByVal So As Integer) As String
    Select Case So
        Case 0: DocChuSo = "không"
        Case 1: DocChuSo = "một"
        Case 2: DocChuSo = "hai"
        Case 3: DocChuSo = "ba"
        Case 4: DocChuSo = "bốn"
        Case 5: DocChuSo = "năm"
        Case 6: DocChuSo = "sáu"
        Case 7: DocChuSo = "bảy"
        Case 8: DocChuSo = "tám"
        Case 9: DocChuSo = "chín"
    End Select
End Function

' Đơn vị hàng
Private Function DonViHang(ByVal Hang As Long) As String
    Select Case Hang
        Case 1: DonViHang = ""
        Case 2: DonViHang = "nghìn"
        Case 3: DonViHang = "triệu"
        Case 4: DonViHang = "tỷ"
        Case 5: DonViHang = "nghìn tỷ"
        Case 6: DonViHang = "triệu tỷ"
        Case Else: DonViHang = ""
    End Select
End Function
